import { Transaction, ActiveGoal } from '../types';

// --- CONFIGURATION CONSTANTS ---
const MOCK_USER_ID = "bank_partner_user_42";

// Defined categories matching the provided Python script
export const CATEGORY_MAP = {
    INCOME: 'Income',
    HOUSING: 'Housing',
    GROCERY: 'Groceries',
    DINING: 'Dining Out',
    TRANSPORT: 'Transportation',
    UTILITIES: 'Utilities',
    ENTERTAINMENT: 'Entertainment',
    SAVINGS: 'Savings & Investment',
    UNCATEGORIZED: 'Uncategorized',
};

// Merchant patterns (Description, Mean Amount, Deviation) - EXACTLY FROM PYTHON SCRIPT
const MERCHANT_PATTERNS: Record<string, [string, number, number][]> = {
    [CATEGORY_MAP.INCOME]: [
        ["PAYCHECK - ABC CORP", 4500.00, 500.00],
        ["FREELANCE DEPOSIT", 800.00, 200.00],
    ],
    [CATEGORY_MAP.HOUSING]: [
        ["RENT PAYMENT", 1800.00, 0.0],
    ],
    [CATEGORY_MAP.UTILITIES]: [
        ["COMCAST INTERNET", 79.99, 5.0],
        ["GEICO AUTO INSURANCE", 125.00, 0.0],
        ["ELECTRIC BILL", 95.00, 30.0],
    ],
    [CATEGORY_MAP.GROCERY]: [
        ["WHOLE FOODS", 65.00, 25.0],
        ["TRADER JOES", 45.00, 15.0],
        ["FARMERS MARKET", 30.00, 10.0],
    ],
    [CATEGORY_MAP.DINING]: [
        ["STARBUCKS #453", 5.50, 1.5],
        ["DOMINOS PIZZA", 30.00, 5.0],
        ["LOCAL RESTAURANT", 55.00, 20.0],
    ],
    [CATEGORY_MAP.ENTERTAINMENT]: [
        ["NETFLIX SUBSCRIPTION", 15.99, 0.0],
        ["AMZN* VIDEO RENTAL", 12.99, 5.0],
        ["BEST BUY ELECTRONICS", 250.00, 100.0],
    ],
    [CATEGORY_MAP.TRANSPORT]: [
        ["UBER TRIP", 18.00, 10.0],
        ["LOCAL GAS STATION", 60.00, 5.0],
    ],
    [CATEGORY_MAP.UNCATEGORIZED]: [
        ["EASYJET FLIGHT", 150.00, 50.0],
        ["PARKING LOT RECEIPT", 8.00, 2.0],
        ["DRY CLEANING 123", 25.50, 5.0],
        ["PET STORE PURCHASE", 35.00, 10.0],
    ]
};

// --- HELPER FUNCTIONS ---

const getRandomDate = (daysAgo: number): Date => {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - daysAgo);
    
    const randomTime = startDate.getTime() + Math.random() * (endDate.getTime() - startDate.getTime());
    return new Date(randomTime);
};

// Box-Muller transform for normal distribution
const normalRandom = (mean: number, stdDev: number): number => {
    const u = 1 - Math.random(); 
    const v = Math.random();
    const z = Math.sqrt( -2.0 * Math.log( u ) ) * Math.cos( 2.0 * Math.PI * v );
    return z * stdDev + mean;
};

const createTransactionId = (): string => {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
};

// --- DATA GENERATION FUNCTIONS ---

const generateTransaction = (category: string, description: string, meanAmount: number, deviation: number, daysAgo: number): Transaction => {
    // Calculate a random amount near the mean
    let amount = Math.max(5.00, Math.round(normalRandom(meanAmount, deviation) * 100) / 100);
    
    // Determine type: Income is credit; everything else is debit.
    const type = category === CATEGORY_MAP.INCOME ? 'credit' : 'debit';

    return {
        id: createTransactionId(),
        userId: MOCK_USER_ID,
        type,
        rawDescription: description,
        amount,
        date: getRandomDate(daysAgo).toISOString(),
        category,
    };
};

export const generateMockTransactions = (daysOfHistory = 60, numTransactions = 40): Transaction[] => {
    const transactions: Transaction[] = [];
    
    // Create the recurring, high-value transactions (Matched Python logic)
    transactions.push(generateTransaction(CATEGORY_MAP.HOUSING, "RENT PAYMENT", 1800.00, 0, 5));
    transactions.push(generateTransaction(CATEGORY_MAP.INCOME, "PAYCHECK - ABC CORP", 4500.00, 50.0, 1));
    transactions.push(generateTransaction(CATEGORY_MAP.INCOME, "PAYCHECK - ABC CORP", 4500.00, 50.0, 30));
    transactions.push(generateTransaction(CATEGORY_MAP.SAVINGS, "AUTOMATED SAVINGS TRANSFER", 500.00, 0, 1));

    // Flatten patterns for random selection
    const allPatterns: {cat: string, desc: string, mean: number, dev: number}[] = [];
    Object.entries(MERCHANT_PATTERNS).forEach(([cat, patterns]) => {
        patterns.forEach(([desc, mean, dev]) => {
            allPatterns.push({ cat, desc, mean, dev });
        });
    });

    // Generate random day-to-day transactions
    for (let i = 0; i < numTransactions - 4; i++) { 
        const randomPattern = allPatterns[Math.floor(Math.random() * allPatterns.length)];
        transactions.push(generateTransaction(randomPattern.cat, randomPattern.desc, randomPattern.mean, randomPattern.dev, daysOfHistory));
    }

    return transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const generateMockGoals = (): ActiveGoal[] => {
    const today = new Date();
    
    // Helper to format date nicely
    const formatDate = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });

    const nextYear = new Date(today);
    nextYear.setDate(today.getDate() + 365);
    
    const fiveYears = new Date(today);
    fiveYears.setDate(today.getDate() + 365 * 5);

    return [
        {
            id: 'goal_holiday_fund',
            name: 'European Holiday Fund',
            targetAmount: 5000.00,
            currentAmount: 500.00,
            targetDate: formatDate(nextYear),
            color: '#10b981' // Green
        },
        {
            id: 'goal_down_payment',
            name: 'House Down Payment',
            targetAmount: 40000.00,
            currentAmount: 5000.00,
            targetDate: formatDate(fiveYears),
            color: '#3b82f6' // Blue
        }
    ];
};