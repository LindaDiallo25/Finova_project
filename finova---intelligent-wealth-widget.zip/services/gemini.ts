import { GoogleGenAI, Chat } from "@google/genai";
import { GoalInput, SimulationResult } from '../types';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

// --- Single Shot Advice (For Smart Recommendation Card) ---
export const generateSmartAdvice = async (input: GoalInput, result: SimulationResult): Promise<string> => {
  const client = getClient();
  if (!client) return "Please connect an API Key to get personalized AI advice.";

  const prompt = `
    You are Finova, a helpful and empathetic financial assistant widget in a banking app.
    
    User Context:
    - Goal: ${input.name}
    - Target: $${input.targetAmount}
    - Timeline: ${input.monthsToTarget} months
    - Current Savings: $${input.currentSaved} (Total), adding $${input.avgMonthlySaving}/month
    - Monthly Income: ${input.monthlyIncome ? '$' + input.monthlyIncome : 'Not provided'}
    
    Analysis:
    - Required Saving: $${result.requiredMonthlySaving.toFixed(2)}/month
    - Status: ${result.feasibilityStatus.replace(/_/g, ' ')}
    - Realism: ${result.realismStatus || 'Unknown'}
    
    Task:
    Provide a single, short, actionable paragraph (max 2 sentences).
    If they are behind, suggest a specific trade-off (e.g., "cutting dining out") or adjustment.
    If they are on track, congratulate them and suggest an optimization (e.g., "putting the surplus in a high-yield account").
    Tone: Professional, encouraging, financial-advisor-like.
  `;

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "Unable to generate advice at this time.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Finova AI is currently offline. Please try again later.";
  }
};

// --- Chat Interface (For Agentic AI Tab) ---
let chatSession: Chat | null = null;

export const sendMessageToFinova = async (message: string, context?: GoalInput): Promise<string> => {
    const client = getClient();
    if (!client) return "Please connect an API Key to chat with Finova.";

    if (!chatSession) {
        chatSession = client.chats.create({
            model: 'gemini-2.5-flash',
            config: {
                systemInstruction: `You are Finova, an intelligent financial agent for a banking application. 
                Your goal is to democratize wealth management. 
                You have access to the user's financial goals and profile.
                Be concise, empathetic, and data-driven. 
                If the user asks about their goals, refer to the provided context.
                
                Context provided:
                Monthly Income: ${context?.monthlyIncome}
                Current Goal: ${context?.name} target ${context?.targetAmount}
                `
            }
        });
    }

    try {
        const response = await chatSession.sendMessage({
            message: message
        });
        return response.text || "I'm thinking...";
    } catch (error) {
        console.error("Gemini Chat Error", error);
        return "I'm having trouble connecting to the bank servers right now.";
    }
}
