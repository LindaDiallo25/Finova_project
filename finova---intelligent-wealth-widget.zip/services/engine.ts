import { GoalInput, SimulationResult, Horizon, FeasibilityStatus, RealismStatus, FinancialProfile } from '../types';

/**
 * Implements the logic described on Pages 17-21 of the PDF.
 * Handles zero savings, horizon classification, and realism checks.
 * Acts as the "Server-Side Python Endpoint" simulation.
 */
export const calculateGoal = (input: GoalInput): SimulationResult => {
  const { targetAmount, monthsToTarget, currentSaved, avgMonthlySaving, monthlyIncome } = input;

  // 1. Core Calculation: Effective Remaining & Required Saving
  const remainingAmount = Math.max(0, targetAmount - currentSaved);
  
  // "Required monthly saving = remaining_amount / months_to_target"
  const requiredMonthlySaving = monthsToTarget > 0 ? remainingAmount / monthsToTarget : remainingAmount;

  // 2. Horizon Classification
  let horizon: Horizon = 'long_term';
  if (monthsToTarget <= 6) horizon = 'short_term';
  else if (monthsToTarget <= 36) horizon = 'medium_term';

  // 3. Prediction & Feasibility
  let predictedCompletionMonths: number | null = null;
  let predictedCompletionDate: Date | null = null;
  let isFeasible = false;
  let feasibilityStatus: FeasibilityStatus = 'unknown';

  if (avgMonthlySaving <= 0) {
    predictedCompletionMonths = null;
    predictedCompletionDate = null;
    isFeasible = false;
    feasibilityStatus = 'behind';
  } else {
    predictedCompletionMonths = remainingAmount / avgMonthlySaving;
    
    // Calculate Date
    if (predictedCompletionMonths !== null && isFinite(predictedCompletionMonths)) {
        const today = new Date();
        const targetDate = new Date(today);
        targetDate.setMonth(today.getMonth() + Math.round(predictedCompletionMonths));
        predictedCompletionDate = targetDate;
    }

    // Feasibility Check
    isFeasible = avgMonthlySaving >= requiredMonthlySaving;

    const ratio = requiredMonthlySaving > 0 ? avgMonthlySaving / requiredMonthlySaving : 1;
    if (ratio >= 1.1) {
      feasibilityStatus = 'on_track_comfortable';
    } else if (ratio >= 1.0) {
      feasibilityStatus = 'on_track_tight';
    } else {
      feasibilityStatus = 'behind';
    }
  }

  // 4. Realism Check (Server-Side Validation Logic)
  let realismStatus: RealismStatus = null;
  let validationMessage = '';

  if (monthlyIncome && monthlyIncome > 0) {
    const incomeRatio = requiredMonthlySaving / monthlyIncome;
    if (incomeRatio > 1.0) {
      realismStatus = 'unrealistic';
      validationMessage = `Validation Error: This goal requires $${requiredMonthlySaving.toFixed(0)}/mo, which exceeds your entire monthly income.`;
    } else if (incomeRatio >= 0.6) {
      realismStatus = 'very_hard';
      validationMessage = `Caution: This goal requires ${(incomeRatio * 100).toFixed(0)}% of your monthly income. This is very difficult to sustain.`;
    } else {
      realismStatus = 'realistic';
    }
  }

  // 5. Message Generation
  // If there is a validation issue (Realism), that takes precedence in the messaging.
  let message = '';
  
  if (validationMessage) {
      message = validationMessage;
  } else if (avgMonthlySaving <= 0) {
    message = `To reach $${targetAmount.toLocaleString()} in ${monthsToTarget}mo, you need $${requiredMonthlySaving.toFixed(0)}/mo. Start saving to see a completion date.`;
  } else {
    const monthsText = predictedCompletionMonths ? predictedCompletionMonths.toFixed(1) : 'unknown';
    const dateText = predictedCompletionDate ? predictedCompletionDate.toLocaleDateString('en-US', {month: 'long', year: 'numeric'}) : '';
    
    if (isFeasible) {
      message = `Great! You need $${requiredMonthlySaving.toFixed(0)}/mo. At $${avgMonthlySaving}/mo, you'll finish by ${dateText} (ahead of schedule).`;
    } else {
      message = `You need $${requiredMonthlySaving.toFixed(0)}/mo. At $${avgMonthlySaving}/mo, it will take until ${dateText}. Try increasing your contribution.`;
    }
  }

  return {
    requiredMonthlySaving,
    predictedCompletionMonths,
    predictedCompletionDate,
    feasibilityStatus,
    realismStatus,
    horizon,
    message,
    isFeasible
  };
};

/**
 * Determines the Financial Profile based on "clustering" logic.
 */
export const determineFinancialProfile = (input: GoalInput): FinancialProfile => {
  // Guard against division by zero if income hasn't loaded
  if (!input.monthlyIncome || input.monthlyIncome === 0) return 'Needs Attention';

  const savingsRate = input.avgMonthlySaving / input.monthlyIncome;

  if (savingsRate < 0) return 'Needs Attention';
  if (savingsRate < 0.1) return 'Spender';
  if (savingsRate < 0.3) return 'Saver';
  return 'Wealth Builder';
};