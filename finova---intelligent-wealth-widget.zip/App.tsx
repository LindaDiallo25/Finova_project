import React, { useState } from 'react';
import { FinovaWidget } from './components/Widget';
import { Key, ShieldCheck } from 'lucide-react';

// Reusing logo component for App Header
const FinovaLogo = () => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 24C8 24 6 20 8 14C10 8 18 4 24 2C24 2 18 6 16 12C14 18 20 22 24 28C24 28 12 32 8 24Z" fill="black"/>
    <path d="M10 16C10 16 9 14 10 11C11 8 15 6 18 5" stroke="url(#paint0_linear_header)" strokeWidth="2" strokeLinecap="round"/>
    <defs>
        <linearGradient id="paint0_linear_header" x1="10" y1="16" x2="18" y2="5" gradientUnits="userSpaceOnUse">
            <stop stopColor="#10B981"/>
            <stop offset="1" stopColor="#EAB308"/>
        </linearGradient>
    </defs>
  </svg>
);

export default function App() {
  const [apiKeySet, setApiKeySet] = useState(false);

  // Check for API Key presence
  React.useEffect(() => {
    if (process.env.API_KEY) {
      setApiKeySet(true);
    }
  }, []);

  const handleApiKeySelection = async () => {
    if (window.aistudio) {
        try {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            if(!hasKey) {
                await window.aistudio.openSelectKey();
            }
            setApiKeySet(true);
        } catch (e) {
            console.error("Error selecting key", e);
        }
    } else {
        alert("AI Studio environment not detected. Using simulation mode.");
        setApiKeySet(true);
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 md:bg-gradient-to-br md:from-slate-100 md:to-slate-200 flex flex-col font-sans text-slate-900">
      
      {/* Minimal Header */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50 shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-3">
               <div className="w-8 h-8 flex items-center justify-center">
                  <FinovaLogo />
               </div>
               <div>
                  <h1 className="font-bold text-lg tracking-tight leading-none bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-emerald-800">FINOVA</h1>
                  <span className="text-[10px] text-slate-500 font-medium hidden sm:block">Bank Integrated Widget</span>
               </div>
            </div>
            <div className="flex items-center gap-4">
               {!apiKeySet ? (
                   <button 
                    onClick={handleApiKeySelection}
                    className="flex items-center gap-2 text-xs font-bold text-amber-700 bg-amber-100 px-4 py-2 rounded-full hover:bg-amber-200 transition-colors shadow-sm"
                   >
                     <Key size={14} /> Connect AI
                   </button>
               ) : (
                  <div className="flex items-center gap-2 text-xs font-medium text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
                    <ShieldCheck size={14} /> AI Connected
                  </div>
               )}
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area - Center Widget */}
      <main className="flex-grow flex items-stretch md:items-center justify-center p-0 md:p-6 overflow-hidden">
          <div className="w-full md:max-w-[420px] h-[calc(100vh-64px)] md:h-[750px] flex flex-col animate-in zoom-in-95 duration-500">
             <div className="hidden md:block mb-4 text-center shrink-0">
                <h2 className="text-xl font-bold text-slate-800">Financial Goal Calculator</h2>
                <p className="text-sm text-slate-500">Data-driven insights from your bank history</p>
             </div>
             
             <FinovaWidget />
             
             <p className="hidden md:block text-center text-[10px] text-slate-400 mt-6 shrink-0">
                &copy; 2025 Finova Project. Secure Environment.
             </p>
          </div>
      </main>
    </div>
  );
}