export type Horizon = 'short_term' | 'medium_term' | 'long_term';

export type FeasibilityStatus = 
  | 'unknown'
  | 'on_track_comfortable' 
  | 'on_track_tight' 
  | 'behind';

export type RealismStatus = 
  | 'unrealistic' 
  | 'very_hard' 
  | 'realistic' 
  | null;

export type FinancialProfile = 
  | 'Needs Attention'
  | 'Spender'
  | 'Saver'
  | 'Wealth Builder';

export interface SimulationResult {
  requiredMonthlySaving: number;
  predictedCompletionMonths: number | null; // Null if infinite/undefined
  predictedCompletionDate: Date | null; // Concrete date
  feasibilityStatus: FeasibilityStatus;
  realismStatus: RealismStatus;
  horizon: Horizon;
  message: string;
  isFeasible: boolean;
}

export interface GoalInput {
  name: string;
  targetAmount: number;
  monthsToTarget: number;
  currentSaved: number;
  avgMonthlySaving: number;
  monthlyIncome?: number;
}

export interface ActiveGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  color: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'credit' | 'debit';
  rawDescription: string;
  amount: number;
  date: string;
  category: string;
}

export interface FinancialStats {
    income: number;
    expenses: number;
    savingsCapacity: number;
}