import React from 'react';
import { Users, Lightbulb, BarChart3, ShieldCheck } from 'lucide-react';

export const ProjectPresentation: React.FC = () => {
  return (
    <div className="space-y-12 max-w-4xl mx-auto py-12 px-6">
      
      {/* Slide 1: Context & Problem */}
      <section className="bg-white p-8 rounded-3xl shadow-lg border-l-8 border-slate-900 transform hover:-translate-y-1 transition-transform duration-300">
        <div className="flex items-center gap-3 mb-6">
           <div className="p-3 bg-red-50 rounded-xl">
             <Users className="text-red-600 w-6 h-6" />
           </div>
           <h2 className="text-2xl font-bold text-slate-800">The Problem: Wealth Management is Elite</h2>
        </div>
        <p className="text-gray-600 leading-relaxed mb-6">
          Traditional banking apps excel at showing <strong>history</strong> (transactions), but they fail to drive <strong>future action</strong>. 
          Most people struggle to answer: <em>"What do I need to do right now to achieve my goals?"</em>
        </p>
        <div className="grid md:grid-cols-2 gap-6">
           <div className="bg-gray-50 p-5 rounded-2xl">
             <h3 className="font-semibold text-slate-900 mb-2">The Gap</h3>
             <p className="text-sm text-gray-500">Millions of individuals (Age 20-60) with regular incomes lack the tools and guidance to secure financial well-being. Inflation and complex products make this worse.</p>
           </div>
           <div className="bg-gray-50 p-5 rounded-2xl">
             <h3 className="font-semibold text-slate-900 mb-2">The Opportunity</h3>
             <p className="text-sm text-gray-500">Transform the banking app from a historical ledger into a <strong>Predictive Financial Agent</strong> using AI & Data.</p>
           </div>
        </div>
      </section>

      {/* Slide 2: Ideation & Concept */}
      <section className="bg-white p-8 rounded-3xl shadow-lg border-l-8 border-blue-600 transform hover:-translate-y-1 transition-transform duration-300">
        <div className="flex items-center gap-3 mb-6">
           <div className="p-3 bg-blue-50 rounded-xl">
             <Lightbulb className="text-blue-600 w-6 h-6" />
           </div>
           <h2 className="text-2xl font-bold text-slate-800">Ideation: Why a Widget?</h2>
        </div>
        <div className="space-y-4 mb-8">
           <p className="text-gray-600">We benchmarked existing solutions (standalone budgeting apps, chatbots) and found a key friction point: <strong>Trust & Security</strong>.</p>
           <ul className="space-y-3">
             <li className="flex items-center gap-3 text-gray-700 bg-blue-50/50 p-3 rounded-xl">
               <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
               Avoids complexity of downloading a new app.
             </li>
             <li className="flex items-center gap-3 text-gray-700 bg-blue-50/50 p-3 rounded-xl">
               <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
               Ensures data compliance (GDPR) by staying in the bank ecosystem.
             </li>
             <li className="flex items-center gap-3 text-gray-700 bg-blue-50/50 p-3 rounded-xl">
               <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
               Seamless B2B2C integration.
             </li>
           </ul>
        </div>
      </section>

      {/* Slide 3: The Solution */}
      <section className="bg-white p-8 rounded-3xl shadow-lg border-l-8 border-green-500 transform hover:-translate-y-1 transition-transform duration-300">
        <div className="flex items-center gap-3 mb-6">
           <div className="p-3 bg-green-50 rounded-xl">
             <BarChart3 className="text-green-600 w-6 h-6" />
           </div>
           <h2 className="text-2xl font-bold text-slate-800">The Finova Solution</h2>
        </div>
        <p className="text-gray-600 mb-6">
          An embeddable, secure widget that delivers <strong>Auditable, Python-First, Serverless</strong> financial intelligence.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
           <div className="border border-gray-100 p-4 rounded-xl text-center hover:bg-green-50 transition-colors">
              <div className="bg-green-100 w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3 text-green-700 font-bold">1</div>
              <h4 className="font-bold text-slate-800 text-sm">Cluster</h4>
              <p className="text-xs text-gray-500 mt-1">Classify users by financial behavior</p>
           </div>
           <div className="border border-gray-100 p-4 rounded-xl text-center hover:bg-green-50 transition-colors">
              <div className="bg-green-100 w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3 text-green-700 font-bold">2</div>
              <h4 className="font-bold text-slate-800 text-sm">Predict</h4>
              <p className="text-xs text-gray-500 mt-1">Forecast completion dates & feasibility</p>
           </div>
           <div className="border border-gray-100 p-4 rounded-xl text-center hover:bg-green-50 transition-colors">
              <div className="bg-green-100 w-10 h-10 rounded-full flex items-center justify-center mx-auto mb-3 text-green-700 font-bold">3</div>
              <h4 className="font-bold text-slate-800 text-sm">Advise</h4>
              <p className="text-xs text-gray-500 mt-1">Generative AI actionable tips</p>
           </div>
        </div>
      </section>

    </div>
  );
};