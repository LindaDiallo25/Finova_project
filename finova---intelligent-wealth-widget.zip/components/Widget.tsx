import React, { useState, useEffect, useRef, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { 
  Target, AlertCircle, 
  BrainCircuit, LayoutDashboard, MessageSquare, 
  Send, ChevronRight, Plus, TrendingUp, Calendar,
  List, Trash2, ArrowDownRight, ArrowUpRight, AlertTriangle, CheckCircle2
} from 'lucide-react';
import { GoalInput, SimulationResult, ChatMessage, FinancialProfile, Transaction, ActiveGoal, FinancialStats } from '../types';
import { calculateGoal, determineFinancialProfile } from '../services/engine';
import { generateSmartAdvice, sendMessageToFinova } from '../services/gemini';
import { generateMockTransactions, generateMockGoals, CATEGORY_MAP } from '../services/mockData';

// Updated Color Palette: Greens, Teals, and warm accents for "Finova" brand feel
const COLORS = [
    '#059669', // Emerald 600 (Income/High match)
    '#10b981', // Emerald 500
    '#34d399', // Emerald 400
    '#0ea5e9', // Sky 500
    '#6366f1', // Indigo 500
    '#eab308', // Yellow 500 (Dining/Warning)
    '#f43f5e', // Rose 500
];

// Custom Logo Component
const FinovaLogo = () => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M8 24C8 24 6 20 8 14C10 8 18 4 24 2C24 2 18 6 16 12C14 18 20 22 24 28C24 28 12 32 8 24Z" fill="black"/>
    <path d="M10 16C10 16 9 14 10 11C11 8 15 6 18 5" stroke="url(#paint0_linear)" strokeWidth="2" strokeLinecap="round"/>
    <defs>
        <linearGradient id="paint0_linear" x1="10" y1="16" x2="18" y2="5" gradientUnits="userSpaceOnUse">
            <stop stopColor="#10B981"/>
            <stop offset="1" stopColor="#EAB308"/>
        </linearGradient>
    </defs>
  </svg>
);

export const FinovaWidget: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'home' | 'goals' | 'analysis' | 'chat'>('home');
  
  // Data State
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [activeGoals, setActiveGoals] = useState<ActiveGoal[]>([]);
  const [stats, setStats] = useState<FinancialStats>({ income: 0, expenses: 0, savingsCapacity: 0 });
  
  // Calculator State
  const [input, setInput] = useState<GoalInput>({
    name: 'New Car',
    targetAmount: 15000,
    monthsToTarget: 24,
    currentSaved: 2000,
    avgMonthlySaving: 0, // Will be set by effect
    monthlyIncome: 0     // Will be set by effect
  });
  const [result, setResult] = useState<SimulationResult | null>(null);
  const [advice, setAdvice] = useState<string | null>(null);
  const [loadingAdvice, setLoadingAdvice] = useState(false);
  const [profile, setProfile] = useState<FinancialProfile>('Needs Attention');

  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Hello! I am Finova, your predictive financial agent. How can I help you reach your goals today?', timestamp: new Date() }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Initialize Mock Data
  useEffect(() => {
    const txs = generateMockTransactions();
    setTransactions(txs);
    setActiveGoals(generateMockGoals());
  }, []);

  // Calculate Aggregates, Stats & Profile
  const spendingData = useMemo(() => {
    const aggregation: Record<string, number> = {};
    let totalIncome = 0;
    let totalExpenses = 0;

    transactions.forEach(tx => {
        if (tx.category === CATEGORY_MAP.INCOME) {
            totalIncome += tx.amount;
        } else {
            // Aggregate expenses for chart
            if (aggregation[tx.category]) {
                aggregation[tx.category] += tx.amount;
            } else {
                aggregation[tx.category] = tx.amount;
            }
            totalExpenses += tx.amount;
        }
    });

    // Assume 2 months of data for averages
    const avgMonthlyIncome = totalIncome / 2;
    const avgMonthlyExpenses = totalExpenses / 2;
    // Capacity is what's left.
    const avgCapacity = Math.max(0, avgMonthlyIncome - avgMonthlyExpenses);

    // Update stats
    setStats({
        income: avgMonthlyIncome,
        expenses: avgMonthlyExpenses,
        savingsCapacity: avgCapacity
    });

    // Update Input Context with real data averages for better defaults
    if (avgMonthlyIncome > 0 && input.monthlyIncome === 0) {
         setInput(prev => ({
             ...prev,
             monthlyIncome: Math.round(avgMonthlyIncome),
             avgMonthlySaving: Math.round(avgCapacity) // Default contribution = capacity
         }));
    }

    // Determine profile
    const calculatedProfile = determineFinancialProfile({
        ...input,
        monthlyIncome: avgMonthlyIncome,
        avgMonthlySaving: avgCapacity
    });
    setProfile(calculatedProfile);

    // Format for Recharts
    const chartData = Object.keys(aggregation)
        .filter(cat => cat !== CATEGORY_MAP.SAVINGS) 
        .map(cat => ({
            name: cat,
            value: aggregation[cat]
        }));

    return chartData.sort((a, b) => b.value - a.value);
  }, [transactions]);


  // Initial Calculation
  useEffect(() => {
    const calc = calculateGoal(input);
    setResult(calc);
  }, [input]);

  // Auto-scroll chat
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleGetAdvice = async () => {
    if (!result) return;
    setLoadingAdvice(true);
    const aiAdvice = await generateSmartAdvice(input, result);
    setAdvice(aiAdvice);
    setLoadingAdvice(false);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMsg: ChatMessage = { role: 'user', text: chatInput, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setChatInput('');
    setIsTyping(true);

    const reply = await sendMessageToFinova(userMsg.text, input);
    
    setIsTyping(false);
    setMessages(prev => [...prev, { role: 'model', text: reply, timestamp: new Date() }]);
  };

  const handleSaveGoal = () => {
     if (result?.realismStatus === 'unrealistic') {
         alert("Cannot save unrealistic goals. Please adjust target or timeline.");
         return;
     }

     const newGoal: ActiveGoal = {
        id: Date.now().toString(),
        name: input.name,
        targetAmount: input.targetAmount,
        currentAmount: input.currentSaved,
        targetDate: result?.predictedCompletionDate ? result.predictedCompletionDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : 'Unknown',
        color: COLORS[activeGoals.length % COLORS.length]
     };
     setActiveGoals(prev => [...prev, newGoal]);
     setActiveTab('goals');
  };

  const handleRemoveGoal = (id: string) => {
    setActiveGoals(prev => prev.filter(g => g.id !== id));
  };

  const getProfileColor = (p: FinancialProfile) => {
    switch(p) {
      case 'Wealth Builder': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'Saver': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'Spender': return 'bg-orange-100 text-orange-700 border-orange-200';
      default: return 'bg-red-100 text-red-700 border-red-200';
    }
  };

  return (
    <div className="bg-white md:rounded-3xl shadow-none md:shadow-2xl overflow-hidden w-full mx-auto border-t md:border border-slate-100 font-sans flex flex-col h-full relative">
      
      {/* 1. Header Area: User Profile & Branding */}
      <div className="bg-white text-slate-800 p-6 pb-6 rounded-b-[2rem] shadow-sm z-20 shrink-0 border-b border-gray-100">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 flex items-center justify-center">
              <FinovaLogo />
            </div>
            <div>
               <h1 className="font-bold text-lg leading-none tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-slate-900 to-emerald-800">FINOVA</h1>
               <span className="text-[10px] text-slate-400 font-medium">Wealth Management</span>
            </div>
          </div>
          <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide border ${getProfileColor(profile)}`}>
            {profile}
          </div>
        </div>
        
        {/* Financial Snapshot */}
        <div className="grid grid-cols-3 gap-2 mt-4 bg-slate-50 p-3 rounded-xl border border-slate-100">
             <div className="text-center border-r border-slate-200">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Income</p>
                <p className="text-sm font-semibold text-slate-800">${stats.income.toLocaleString()}</p>
             </div>
             <div className="text-center border-r border-slate-200">
                <p className="text-[10px] text-slate-400 uppercase font-bold">Spend</p>
                <p className="text-sm font-semibold text-slate-800">${stats.expenses.toLocaleString()}</p>
             </div>
             <div className="text-center">
                <p className="text-[10px] text-slate-400 uppercase font-bold text-emerald-600">Capacity</p>
                <p className="text-sm font-bold text-emerald-600">+${stats.savingsCapacity.toLocaleString()}</p>
             </div>
        </div>
      </div>

      {/* 2. Main Content Area (Scrollable) */}
      <div className="flex-grow bg-slate-50 overflow-y-auto custom-scrollbar relative">
        
        {/* --- TAB: SIMULATOR (HOME) --- */}
        {activeTab === 'home' && (
          <div className="p-5 space-y-6 pb-24 animate-in fade-in slide-in-from-bottom-4 duration-500">
            
            {/* A. Smart Recommendation Card */}
            {!advice ? (
               <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-1 shadow-lg cursor-pointer group" onClick={handleGetAdvice}>
                 <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 flex items-center justify-between hover:bg-white/20 transition-all">
                    <div className="flex items-center gap-3">
                       <div className="bg-white/20 p-2 rounded-full">
                          <BrainCircuit className="text-white" size={20} />
                       </div>
                       <div>
                          <p className="text-white font-semibold text-sm">Finova AI Insight</p>
                          <p className="text-emerald-100 text-xs">{loadingAdvice ? "Analyzing..." : "Tap for personalized advice"}</p>
                       </div>
                    </div>
                    <ChevronRight className="text-white opacity-50 group-hover:opacity-100" size={20}/>
                 </div>
               </div>
            ) : (
               <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-5 border border-emerald-100 shadow-sm relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-100 rounded-full blur-3xl -translate-y-10 translate-x-10 opacity-50"></div>
                 <div className="flex items-center gap-2 mb-2">
                    <BrainCircuit size={16} className="text-emerald-600" />
                    <span className="text-xs font-bold text-emerald-800 uppercase tracking-wider">Smart Recommendation</span>
                 </div>
                 <p className="text-sm text-slate-700 leading-relaxed italic relative z-10">"{advice}"</p>
                 <button onClick={() => setAdvice(null)} className="text-[10px] text-slate-400 mt-2 underline hover:text-emerald-600">Refresh</button>
               </div>
            )}

            {/* B. Goal Calculator */}
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
              <div className="flex items-center gap-2 mb-4">
                 <Target className="text-emerald-500" size={18} />
                 <h3 className="font-bold text-slate-800 text-sm">Simulator</h3>
              </div>
              
              <div className="space-y-4">
                 <div className="grid grid-cols-1 gap-3">
                    {/* Goal Name */}
                    <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase ml-1 mb-1 block">Goal Name</label>
                        <input 
                        type="text" 
                        value={input.name}
                        onChange={(e) => setInput({...input, name: e.target.value})}
                        className="w-full p-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-100 outline-none"
                        placeholder="e.g. New Car"
                        />
                    </div>
                    
                    {/* Target & Time */}
                    <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase ml-1 mb-1 block">Target Amount</label>
                          <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">$</span>
                            <input 
                              type="number" 
                              value={input.targetAmount}
                              onChange={(e) => setInput({...input, targetAmount: Number(e.target.value)})}
                              className="w-full pl-6 p-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-100 outline-none"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase ml-1 mb-1 block">Timeline (Months)</label>
                          <input 
                            type="number" 
                            value={input.monthsToTarget}
                            onChange={(e) => setInput({...input, monthsToTarget: Number(e.target.value)})}
                            className="w-full p-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 focus:ring-emerald-100 outline-none"
                          />
                        </div>
                    </div>

                    {/* Savings Contribution */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Monthly Contribution</label>
                        <button 
                            onClick={() => setInput({...input, avgMonthlySaving: Math.round(stats.savingsCapacity)})}
                            className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md hover:bg-emerald-100"
                        >
                            Max: ${Math.round(stats.savingsCapacity)}
                        </button>
                      </div>
                      <div className="relative">
                         <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">$</span>
                         <input 
                          type="number" 
                          value={input.avgMonthlySaving}
                          onChange={(e) => setInput({...input, avgMonthlySaving: Number(e.target.value)})}
                          className={`w-full pl-6 p-2.5 bg-slate-50 border-none rounded-xl text-sm font-medium focus:ring-2 outline-none ${input.avgMonthlySaving > stats.savingsCapacity ? 'ring-2 ring-orange-200 text-orange-600' : 'focus:ring-emerald-100'}`}
                        />
                      </div>
                      {input.avgMonthlySaving > stats.savingsCapacity && (
                          <p className="text-[10px] text-orange-500 mt-1 flex items-center gap-1">
                              <AlertCircle size={10} /> Exceeds your avg capacity (${Math.round(stats.savingsCapacity)})
                          </p>
                      )}
                    </div>
                 </div>

                 {/* Real-time Calculation Result */}
                 {result && (
                   <div className={`bg-slate-50 rounded-xl p-4 border ${result.realismStatus === 'unrealistic' || result.realismStatus === 'very_hard' ? 'border-red-100 bg-red-50/50' : 'border-slate-100'}`}>
                      <div className="flex justify-between items-center mb-2">
                         <span className="text-xs font-semibold text-slate-500">Required</span>
                         <span className="text-lg font-bold text-slate-800">${result.requiredMonthlySaving.toFixed(0)}<span className="text-xs font-normal text-slate-400">/mo</span></span>
                      </div>
                      
                      {/* Feasibility Bar or Validation Error */}
                      {result.realismStatus === 'unrealistic' || result.realismStatus === 'very_hard' ? (
                          <div className="flex items-center gap-2 mb-2 p-2 bg-white rounded-lg border border-red-100">
                              <AlertTriangle size={16} className="text-red-500" />
                              <span className="text-xs font-bold text-red-600 uppercase">Validation Check Failed</span>
                          </div>
                      ) : (
                          <div className="flex items-center gap-2 mb-2">
                            {result.feasibilityStatus === 'behind' ? (
                            <div className="flex-1 bg-red-100 h-2 rounded-full overflow-hidden">
                                <div className="bg-red-500 h-full w-1/2 rounded-full"></div>
                            </div>
                            ) : (
                            <div className="flex-1 bg-emerald-100 h-2 rounded-full overflow-hidden">
                                <div className="bg-emerald-500 h-full w-full rounded-full"></div>
                            </div>
                            )}
                            <span className={`text-[10px] font-bold uppercase ${result.feasibilityStatus === 'behind' ? 'text-red-600' : 'text-emerald-600'}`}>
                            {result.feasibilityStatus === 'behind' ? 'Behind' : 'On Track'}
                            </span>
                          </div>
                      )}
                      
                      {/* Timeline/Date Display */}
                      {result.realismStatus !== 'unrealistic' && (
                        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-slate-200/50">
                            <Calendar size={14} className="text-slate-400"/>
                            {result.predictedCompletionDate ? (
                                <span className="text-xs text-slate-600">
                                    Estimated Completion: <strong className="text-slate-900">{result.predictedCompletionDate.toLocaleDateString('en-US', {month: 'short', year: 'numeric'})}</strong>
                                </span>
                            ) : (
                                <span className="text-xs text-slate-500">Completion date unknown</span>
                            )}
                        </div>
                      )}

                      <p className={`text-xs leading-snug mt-2 italic ${result.realismStatus === 'unrealistic' ? 'text-red-600 font-medium' : 'text-slate-500'}`}>
                         {result.message}
                      </p>
                   </div>
                 )}
                 
                 <button 
                    onClick={handleSaveGoal}
                    className={`w-full py-3 rounded-xl text-sm font-bold shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2 
                        ${result?.realismStatus === 'unrealistic' ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-slate-900 text-white hover:bg-slate-800'}`}
                    disabled={result?.realismStatus === 'unrealistic'}
                 >
                    <Plus size={16} /> Save Goal
                 </button>
              </div>
            </div>
          </div>
        )}

        {/* --- TAB: GOALS (ACTIVE) --- */}
        {activeTab === 'goals' && (
           <div className="p-5 space-y-4 pb-24 animate-in fade-in slide-in-from-right-4 duration-300">
               <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 ml-1">Your Active Goals ({activeGoals.length})</h3>
               
               {activeGoals.length === 0 ? (
                 <div className="text-center py-10 opacity-50">
                    <Target className="mx-auto mb-2 text-slate-300" size={32} />
                    <p className="text-sm text-slate-500">No active goals yet.</p>
                    <button onClick={() => setActiveTab('home')} className="text-xs text-emerald-600 font-bold mt-2">Create one in Simulator</button>
                 </div>
               ) : (
                   <div className="space-y-3">
                    {activeGoals.map(goal => (
                        <div key={goal.id} className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center justify-between group">
                        <div className="flex-1 mr-4">
                            <div className="flex justify-between mb-1">
                                <span className="text-sm font-semibold text-slate-800">{goal.name}</span>
                                <span className="text-xs font-medium text-slate-500">Target: ${goal.targetAmount.toLocaleString()}</span>
                            </div>
                            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div 
                                className="h-full rounded-full" 
                                style={{ width: `${(goal.currentAmount / goal.targetAmount) * 100}%`, backgroundColor: goal.color }}
                                ></div>
                            </div>
                            <div className="flex justify-between mt-1 text-[10px] text-slate-400">
                                <span>${goal.currentAmount.toLocaleString()} saved</span>
                                <span>By {goal.targetDate}</span>
                            </div>
                        </div>
                        <button 
                            onClick={() => handleRemoveGoal(goal.id)}
                            className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                        >
                            <Trash2 size={16} />
                        </button>
                        </div>
                    ))}
                   </div>
               )}
           </div>
        )}

        {/* --- TAB: ANALYSIS (TRANSACTIONS) --- */}
        {activeTab === 'analysis' && (
            <div className="p-5 space-y-6 pb-24 animate-in fade-in slide-in-from-right-4 duration-300">
                
                {/* Spending Analysis Chart */}
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                    <h3 className="text-sm font-bold text-slate-800 mb-2 flex items-center gap-2">
                        <TrendingUp size={16} className="text-emerald-500"/> Spending Analysis
                    </h3>
                    {spendingData.length > 0 ? (
                        <div className="h-40 w-full flex items-center">
                            <div className="w-1/2 h-full">
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={spendingData}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={30}
                                        outerRadius={50}
                                        paddingAngle={5}
                                        dataKey="value"
                                    >
                                        {spendingData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                        ))}
                                    </Pie>
                                    <Tooltip 
                                        formatter={(value: number) => `$${value.toFixed(2)}`}
                                        contentStyle={{ borderRadius: '12px', fontSize: '12px' }}
                                    />
                                </PieChart>
                            </ResponsiveContainer>
                            </div>
                            <div className="w-1/2 space-y-1 overflow-y-auto max-h-36 custom-scrollbar pr-2">
                                {spendingData.map((entry, index) => (
                                    <div key={index} className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                                            <span className="text-[10px] text-slate-600 truncate max-w-[80px]">{entry.name}</span>
                                        </div>
                                        <span className="text-[10px] font-medium text-slate-800">${entry.value.toFixed(0)}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="h-40 w-full flex items-center justify-center text-xs text-slate-400">
                            Loading transactions...
                        </div>
                    )}
                </div>

                {/* Transaction List */}
                <div>
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 ml-1 flex items-center gap-2">
                        <List size={14} /> Recent Transactions
                    </h3>
                    <div className="space-y-2">
                        {transactions.map(tx => (
                            <div key={tx.id} className="bg-white p-3 rounded-xl border border-slate-50 flex items-center justify-between shadow-sm">
                                <div className="flex items-center gap-3">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.type === 'credit' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-50 text-slate-400'}`}>
                                        {tx.type === 'credit' ? <ArrowDownRight size={14} /> : <ArrowUpRight size={14} />}
                                    </div>
                                    <div>
                                        <p className="text-xs font-bold text-slate-700">{tx.rawDescription}</p>
                                        <p className="text-[10px] text-slate-400">{new Date(tx.date).toLocaleDateString()} • {tx.category}</p>
                                    </div>
                                </div>
                                <span className={`text-xs font-bold ${tx.type === 'credit' ? 'text-emerald-600' : 'text-slate-800'}`}>
                                    {tx.type === 'credit' ? '+' : '-'}${tx.amount.toFixed(2)}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

            </div>
        )}

        {/* --- TAB: AGENT (CHAT) --- */}
        {activeTab === 'chat' && (
          <div className="flex flex-col h-full bg-white">
             {/* Chat View */}
             <div className="flex-grow p-4 space-y-4 overflow-y-auto">
                {messages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                     <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${msg.role === 'user' ? 'bg-emerald-600 text-white rounded-tr-none' : 'bg-slate-100 text-slate-800 rounded-tl-none'}`}>
                        {msg.text}
                     </div>
                  </div>
                ))}
                {isTyping && (
                  <div className="flex justify-start">
                     <div className="bg-slate-100 p-3 rounded-2xl rounded-tl-none text-slate-400 text-xs italic">
                        Finova is typing...
                     </div>
                  </div>
                )}
                <div ref={chatEndRef} />
             </div>

             <div className="p-4 border-t border-slate-100 bg-white pb-24">
                <form onSubmit={handleSendMessage} className="relative">
                   <input 
                     type="text" 
                     value={chatInput}
                     onChange={(e) => setChatInput(e.target.value)}
                     placeholder="Ask Finova..."
                     className="w-full bg-slate-50 border border-slate-200 rounded-full py-3 pl-4 pr-12 text-sm focus:ring-2 focus:ring-emerald-100 outline-none"
                   />
                   <button 
                     type="submit"
                     disabled={!chatInput.trim() || isTyping}
                     className="absolute right-1 top-1 bottom-1 bg-emerald-600 w-10 h-10 rounded-full flex items-center justify-center text-white disabled:opacity-50 disabled:cursor-not-allowed hover:bg-emerald-700 transition-colors"
                   >
                     <Send size={16} />
                   </button>
                </form>
             </div>
          </div>
        )}
      </div>

      {/* 3. Bottom Tab Navigation (Expanded) */}
      <div className="absolute bottom-6 left-4 right-4 md:left-6 md:right-6 z-30">
        <div className="bg-slate-900/95 backdrop-blur-md text-white rounded-2xl p-2 shadow-2xl flex items-center justify-between px-4 border border-white/10">
           
           <button 
             onClick={() => setActiveTab('home')}
             className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${activeTab === 'home' ? 'text-emerald-400' : 'text-slate-400 hover:text-white'}`}
           >
              <LayoutDashboard size={18} />
              <span className="text-[9px] font-medium">Simulator</span>
           </button>

           <button 
             onClick={() => setActiveTab('goals')}
             className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${activeTab === 'goals' ? 'text-emerald-400' : 'text-slate-400 hover:text-white'}`}
           >
              <Target size={18} />
              <span className="text-[9px] font-medium">Goals</span>
           </button>

           <button 
             onClick={() => setActiveTab('analysis')}
             className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${activeTab === 'analysis' ? 'text-emerald-400' : 'text-slate-400 hover:text-white'}`}
           >
              <TrendingUp size={18} />
              <span className="text-[9px] font-medium">Analysis</span>
           </button>
           
           <button 
             onClick={() => setActiveTab('chat')}
             className={`flex flex-col items-center gap-1 p-2 rounded-xl transition-all ${activeTab === 'chat' ? 'text-emerald-400' : 'text-slate-400 hover:text-white'}`}
           >
              <MessageSquare size={18} />
              <span className="text-[9px] font-medium">Agent</span>
           </button>

        </div>
      </div>
      
    </div>
  );
};